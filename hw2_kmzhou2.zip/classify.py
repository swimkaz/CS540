import os
import math


# These first two functions require os operations and so are completed for you
# Completed for you
def load_training_data(vocab, directory):
    """ Create the list of dictionaries """
    top_level = os.listdir(directory)
    dataset = []
    for d in top_level:
        if d[-1] == '/':
            label = d[:-1]
            subdir = d
        else:
            label = d
            subdir = d + "/"
        files = os.listdir(directory + subdir)
        for f in files:
            bow = create_bow(vocab, directory + subdir + f)
            dataset.append({'label': label, 'bow': bow})
    return dataset


# Completed for you
def create_vocabulary(directory, cutoff):
    """ Create a vocabulary from the training directory
        return a sorted vocabulary list
    """

    top_level = os.listdir(directory)
    vocab = {}
    for d in top_level:
        subdir = d if d[-1] == '/' else d + '/'
        files = os.listdir(directory + subdir)
        for f in files:
            with open(directory + subdir + f, 'r', encoding='utf-8') as doc:
                for word in doc:
                    word = word.strip()
                    if not word in vocab and len(word) > 0:
                        vocab[word] = 1
                    elif len(word) > 0:
                        vocab[word] += 1
    return sorted([word for word in vocab if vocab[word] >= cutoff])


# The rest of the functions need modifications ------------------------------
# Needs modifications
def create_bow(vocab, filepath):
    """ Create a single dictionary for the data
        Note: label may be None
    """
    bow = {}

    file = open(filepath, "r", encoding='utf-8')

    files = []
    files = file.readlines()

    dictionary = []
    dictionary = vocab

    v = list()
    i = 0
    j = 0
    n = True
    count = 0;
    while i <= len(files)-1:
        word = files[i]
        word = word.replace('\n', '')
        word = word.strip()
        i += 1
        j = 0
        n = True
        while j <= len(vocab)-1:
            vocabulary = dictionary[j]
            j += 1
            if word == vocabulary:
                if word not in v:
                    bow[word] = 0
                    bow[word] += 1
                    v.append(word)
                else:
                    bow[word] += 1
                n = False
        if n:
            if count == 0:
                bow[None] = 0
            count += 1
            bow[None] += 1

    return bow

# Needs modifications
def prior(training_data, label_list):
    """ return the prior probability of the label in the training set
        => frequency of DOCUMENTS
    """
    smooth = 1  # smoothing factor
    logprob = {}
    data = label_list

    labels = len(data)

    training = training_data

    length = len(training)

    label1 = 0
    label2 = 0
    i = 0
    data1 = data[0]
    data2 = data[1]
    while i <= length-1:
        trains = {}
        trains = training[i]
        label = trains.get('label')
        if label == data1:
            label1 += 1
        elif label == data2:
            label2 += 1
        i += 1

    result1 = label1 + smooth
    result2 = label2 + smooth
    number1 = length + labels
    result1 = result1/number1
    result2 = result2/number1

    result1 = math.log(result1)
    result2 = math.log(result2)
    lab1: str = data[0]
    lab2: str = data[1]
    logprob[lab1] = result1
    logprob[lab2] = result2

    return logprob


# Needs modifications
def p_word_given_label(vocab, training_data, label):
    """ return the class conditional probability of label over all words, with smoothing """

    smooth = 1  # smoothing factor
    word_prob = {}

    vocabulary = []
    vocabulary = vocab
    training = []
    training = training_data
    label = label
    numberwords = 0
    size = len(vocabulary)

    h = 0
    while h < len(training):
        data = {}
        data = training[h]
        if data['label'] == label:
            words = {}
            words = data['bow']
            i = 0
            while i < len(words):
                ks = []
                ks = list(words.keys())
                keys = []
                keys = ks
                key = keys[i]
                num = words[key]
                numberwords += num
                i += 1
        h += 1

    g = 0
    c = 0
    while g <= len(vocabulary)-1:
        word = vocabulary[g]
        j = 0
        word_prob[word] = 0
        while j <= len(training)-1:
            data = {}
            data = training[j]
            if data['label'] == label:
                words = {}
                words = data['bow']
                w = list(words.keys())
                if word in w:
                    numb = words[word]
                    while numb != 0:
                        word_prob[word] += 1
                        c += 1
                        numb = numb - 1

            j += 1
        g += 1

    if c <= numberwords-1:
        n = numberwords - c
        word_prob[None] = n
    else:
        word_prob[None] = 0

    k = 0
    ke = []
    ke = list(word_prob.keys())
    while k <= len(ke)-1:
        f = ke[k]
        nums = word_prob[f]
        result = nums + 1
        den = numberwords + size
        den += 1
        result = result/den
        result = math.log(result)
        word_prob[f] = result
        k += 1

    return word_prob


##################################################################################
# Needs modifications
def train(training_directory, cutoff):
    """ return a dictionary formatted as follows:
            {
             'vocabulary': <the training set vocabulary>,
             'log prior': <the output of prior()>,
             'log p(w|y=2016)': <the output of p_word_given_label() for 2016>,
             'log p(w|y=2020)': <the output of p_word_given_label() for 2020>
            }
    """
    retval = {}
    label_list = os.listdir(training_directory)

    voc = []
    voc = create_vocabulary(training_directory, cutoff)
    trainload = []
    trainload = load_training_data(voc, training_directory)
    pr = {}
    pr = prior(trainload, ['2020', '2016'])
    log1 = {}
    log1 = p_word_given_label(voc, trainload, '2016')
    log2 = {}
    log2 = p_word_given_label(voc, trainload, '2020')
    retval['vocabulary'] = voc
    retval['log prior'] = pr
    retval['log p(w|y=2016)'] = log1
    retval['log p(w|y=2020)'] = log2

    return retval


# Needs modifications
def classify(model, filepath):
    """ return a dictionary formatted as follows:
            {
             'predicted y': <'2016' or '2020'>,
             'log p(y=2016|x)': <log probability of 2016 label for the document>,
             'log p(y=2020|x)': <log probability of 2020 label for the document>
            }
    """
    retval = {}
    # TODO
    vo = {}
    vo = model['vocabulary']
    bag = {}
    bag = create_bow(vo, filepath)
    log1 = {}
    log1 = model['log p(w|y=2016)']
    log2 = {}
    log2 = model['log p(w|y=2020)']
    pri = {}
    pri = model['log prior']
    pri1 = 0
    pri1 = pri['2016']
    pri2 = 0
    pri2 = pri['2020']
    prob1 = 0
    prob2 = 0
    guess = ''

    i = 0
    keys = []
    keys = list(bag.keys())
    while i <= len(keys)-1:
        k = keys[i]
        probability = bag[k]
        pro1 = probability * log1[k]
        prob1 = prob1 + pro1
        pro2 = probability * log2[k]
        prob2 = prob2 + pro2
        i += 1

    prob1 = prob1 + pri1
    prob2 = prob2 + pri2

    if prob1 > prob2:
        guess = '2016'
    else:
        guess = '2020'

    retval['log p(y=2016|x)'] = prob1
    retval['log p(y=2020|x)'] = prob2
    retval['predicted y'] = guess

    return retval
