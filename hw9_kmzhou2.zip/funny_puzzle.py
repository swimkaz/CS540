import heapq
import copy


def print_succ(state):
    succ = []
    succ = successors(state)

    succ = sorted(succ)
    for j in range(len(succ)):
        h = heuristics(succ[j])
        print(str(succ[j]) + " h=" + str(int(h)))


def heuristics(state):
    goal = [1, 2, 3, 4, 5, 6, 7, 8, 0]
    if state == goal:
        return 0
    num = 0
    for i in range(8):
        number = goal[i]
        for y in range(9):
            if state[y] == number:
                row1 = int(y/3)
                col1 = int(y%3)
                row2 = int(i/3)
                col2 = int(i%3)
                n = manhattan(row1, col1, row2, col2)
                num += n

    return num


def manhattan(a, b, c, d):
    res = abs(a-c) + abs(b-d)
    return res


def successors(state):
    succ = []
    num = 0
    for i in range(len(state)):
        if state[i] == 0:
            num = i
    col = int(num % 3)
    row = int(num / 3)
    if (num + 3) < 9:
        newstate = copy.deepcopy(state)
        n = newstate[num+3]
        newstate[num] = n
        newstate[num+3] = 0
        succ.append(newstate)

    if (num - 3) >= 0:
        newstate = copy.deepcopy(state)
        n = newstate[num-3]
        newstate[num] = n
        newstate[num-3] = 0
        succ.append(newstate)

    if (col + 1) < 3:
        newstate = copy.deepcopy(state)
        n = newstate[num+1]
        newstate[num] = n
        newstate[num+1] = 0
        succ.append(newstate)

    if (col - 1) >= 0:
        newstate = copy.deepcopy(state)
        n = newstate[num-1]
        newstate[num] = n
        newstate[num-1] = 0
        succ.append(newstate)

    succ = sorted(succ)
    return succ


def solve(state):
    OPEN = []
    CLOSED = []
    result = []
    goal = [1, 2, 3, 4, 5, 6, 7, 8, 0]

    h = heuristics(state)
    res = [(h, state, (0,  h , -1))]
    heapq.heappush(OPEN, res)
    while len(OPEN) != 0:
        [(p, st, (c, h, parent))] = heapq.heappop(OPEN)
        res = [(p, st, (c, h, parent))]
        CLOSED.append(res)

        if st == goal:
            result.append(st)
            pt = parent
            while pt >= 0:
                [(p, st, (c, h, parent))] = CLOSED[pt]
                result.append(st)
                pt = parent
            moves = 0
            for y in range(len(result)):
                num = (len(result)-y-1)
                final = list(result[num])
                h = heuristics(final)
                print(str(final) + " h=" + str(h) + " moves: " + str(moves))
                moves += 1

            break
        parent = len(CLOSED)
        parent -= 1
        c += 1
        succs = successors(st)
        exist = 0
        for i in range(len(succs)):
            nstate = succs[i]
            for x in range(len(CLOSED)):
                [(p, newstate, (co, h , pare))] = CLOSED[x]
                if newstate == nstate:
                    exist = 1

            if exist == 0:
                h = heuristics(nstate)
                p = c + h
                res = [(p, nstate, (c, h , parent))]
                heapq.heappush(OPEN, res)

            exist = 0



