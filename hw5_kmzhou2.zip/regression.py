import csv
import math
import numpy as np
import random
from matplotlib import pyplot as plt
import matplotlib.patches as mpatches

# Feel free to import other packages, if needed.
# As long as they are supported by CSL machines.


def get_dataset(filename):
    """
    INPUT:
        filename - a string representing the path to the csv file.

    RETURNS:
        An n by m+1 array, where n is # data points and m is # features.
        The labels y should be in the first column.
    """
    dataset = None
    dataset = list()
    with open(filename, newline='') as file:
        reader = csv.DictReader(file)
        n = 0
        for row in reader:
            dataset.append(row["BODYFAT"])
            dataset.append(row["DENSITY"])
            dataset.append(row["AGE"])
            dataset.append(row["WEIGHT"])
            dataset.append(row["HEIGHT"])
            dataset.append(row["ADIPOSITY"])
            dataset.append(row["NECK"])
            dataset.append(row["CHEST"])
            dataset.append(row["ABDOMEN"])
            dataset.append(row["HIP"])
            dataset.append(row["THIGH"])
            dataset.append(row["KNEE"])
            dataset.append(row["ANKLE"])
            dataset.append(row["BICEPS"])
            dataset.append(row["FOREARM"])
            dataset.append(row["WRIST"])
            n += 1

    dataset = np.array(dataset)
    dataset = np.array(dataset.reshape((n, 16)))
    dataset = dataset.astype(np.float)

    return dataset


def print_stats(dataset, col):
    """
    INPUT: 
        dataset - the body fat n by m+1 array
        col     - the index of feature to summarize on. 
                  For example, 1 refers to density.

    RETURNS:
        None
    """
    size = len(dataset)
    print(size)
    i = 0
    sum = 0
    while i < size:
        int = dataset[i][col]
        sum += int
        i += 1

    j = 0
    mean = sum/size
    print('{:.2f}'.format(mean))
    number = 0
    while j < size:
        num = dataset[j][col] - mean
        num = num * num
        number += num
        j += 1

    q = size - 1
    sd = number/q
    sd = math.sqrt(sd)
    print('{:.2f}'.format(sd))

    pass


def regression(dataset, cols, betas):
    """
    INPUT: 
        dataset - the body fat n by m+1 array
        cols    - a list of feature indices to learn.
                  For example, [1,8] refers to density and abdomen.
        betas   - a list of elements chosen from [beta0, beta1, ..., betam]

    RETURNS:
        mse of the regression model
    """
    mse = None
    size1 = len(dataset)
    size2 = len(cols)
    i = 0
    num = 0
    while i < size1:
        res = betas[0]
        j = 0
        while j < size2:
            integer = dataset[i][cols[j]]
            integer = integer * betas[j+1]
            res += integer
            j += 1

        res = res - dataset[i][0]
        i += 1
        res = res * res
        num += res

    num = num/size1
    mse = num

    return mse


def gradient_descent(dataset, cols, betas):
    """
    INPUT: 
        dataset - the body fat n by m+1 array
        cols    - a list of feature indices to learn.
                  For example, [1,8] refers to density and abdomen.
        betas   - a list of elements chosen from [beta0, beta1, ..., betam]

    RETURNS:
        An 1D array of gradients
    """
    grads = None
    size1 = len(dataset)
    size2 = len(cols)
    size3 = len(betas)
    grads = np.zeros(size3)
    a = 0
    num = 0
    while a < size3:
        i = 0
        num = 0
        while i < size1:
            res = betas[0]
            j = 0
            while j < size2:
                integer = dataset[i][cols[j]]
                integer = integer * betas[j + 1]
                res += integer
                j += 1

            res = res - dataset[i][0]

            if a != 0:
                res = res * dataset[i][cols[a-1]]
            i += 1
            num += res

        num = num / size1
        num = 2 * num
        grads[a] = num
        a += 1

    return grads


def iterate_gradient(dataset, cols, betas, T, eta):
    """
    INPUT:
        dataset - the body fat n by m+1 array
        cols    - a list of feature indices to learn.
                  For example, [1,8] refers to density and abdomen.
        betas   - a list of elements chosen from [beta0, beta1, ..., betam]
        T       - # iterations to run
        eta     - learning rate

    RETURNS:
        None
    """
    times = T
    i = 0
    col = np.array(cols)
    beta = np.array(betas)

    while i < times:
        res = np.array(gradient_descent(dataset, col, beta))
        beta = beta.astype(np.float)
        j = 0
        while j < len(beta):
            num = res[j]
            num = num * eta
            b = beta[j]
            b = b - num
            beta[j] = b
            j += 1

        mse = regression(dataset, col, beta)
        print(' ', i+1 , end='')
        print(' ', '{:.2f}'.format(mse) , end='')
        a = 0
        while a < len(beta):
            print(' ', '{:.2f}'.format(beta[a]), end='')
            a += 1

        print("")
        i += 1

    pass


def compute_betas(dataset, cols):
    """
    INPUT: 
        dataset - the body fat n by m+1 array
        cols    - a list of feature indices to learn.
                  For example, [1,8] refers to density and abdomen.

    RETURNS:
        A tuple containing corresponding mse and several learned betas
    """
    betas = None
    mse = None
    size1 = len(dataset)
    size2 = len(cols)
    data = np.zeros((size1, size2+1))
    data = data.astype(np.float)
    y = np.zeros(size1)
    y = y.astype(np.float)
    i = 0
    while i < size1:
        j = 0
        while j <= size2:
            if j == 0:
                data[i][j] = 1
            else:
                data[i][j] = dataset[i][cols[j-1]]
            j += 1
        y[i] = dataset[i][0]
        i += 1

    transpose = data.transpose()
    res = np.array(transpose.dot(data))
    res = np.array(np.linalg.inv(res))
    res = np.array(res.dot(transpose))
    res = np.array(res.dot(y))
    size3 = len(cols)
    a = 1
    betas = np.zeros(size3+1)
    betas = betas.astype(np.float)
    betas[0] = res[0]
    while a <= size3:
        betas[a] = res[cols[a-1]]
        a += 1

    mse = regression(dataset, cols, betas)

    return (mse, *betas)


def predict(dataset, cols, features):
    """
    INPUT: 
        dataset - the body fat n by m+1 array
        cols    - a list of feature indices to learn.
                  For example, [1,8] refers to density and abdomen.
        features- a list of observed values

    RETURNS:
        The predicted body fat percentage value
    """
    result = None
    betas = np.array(compute_betas(dataset, cols))
    betas = betas.astype(np.float)
    f = np.array(features)
    f = f.astype(np.float)
    size = len(betas)
    i = 2
    result = betas[1]
    while i < size:
        num = betas[i] * f[i-2]
        result += num
        i += 1

    return result


def synthetic_datasets(betas, alphas, X, sigma):
    """
    Input:
        betas  - parameters of the linear model
        alphas - parameters of the quadratic model
        X      - the input array (shape is guaranteed to be (n,1))
        sigma  - standard deviation of noise

    RETURNS:
        Two datasets of shape (n,2) - linear one first, followed by quadratic.
    """

    array1 = np.zeros((len(X), 2))
    array2 = np.zeros((len(X), 2))
    size = len(X)
    i = 0
    while i < size:
        z1 = np.random.normal(0, sigma)
        z2 = np.random.normal(0, sigma)
        num1 = betas[0]
        a = betas[1] * X[i][0]
        num1 = num1 + a
        num1 = num1 + z1

        num2 = alphas[0]
        b = X[i][0] * X[i][0]
        b = alphas[1] * b
        num2 = num2 + b
        num2 = num2 + z2

        array1[i][0] = num1
        array1[i][1] = X[i][0]

        array2[i][0] = num2
        array2[i][1] = X[i][0]
        i += 1

    return array1, array2


def plot_mse():
    from sys import argv
    if len(argv) == 2 and argv[1] == 'csl':
        import matplotlib
        matplotlib.use('Agg')

    # Generate datasets and plot an MSE-sigma graph
    X = np.zeros((1000, 1))
    i = 0
    while i < 1000:
        num = random.random()
        if i % 2 == 0:
            num = -1 * num
        num = num * 100
        X[i][0] = num
        i += 1

    j = 0
    betas = np.zeros(2)
    alphas = np.zeros(2)
    while j < 2:
        num1 = random.randint(1, 9)
        num2 = random.randint(1, 9)
        betas[j] = num1
        alphas[j] = num2
        j += 1

    sigma = np.array([.001, .01, .1, 1, 10, 100, 1000, 10000, 100000])

    sigma0array1, sigma0array2 = synthetic_datasets(betas, alphas, X, sigma[0])
    sigma1array1, sigma1array2 = synthetic_datasets(betas, alphas, X, sigma[1])
    sigma2array1, sigma2array2 = synthetic_datasets(betas, alphas, X, sigma[2])
    sigma3array1, sigma3array2 = synthetic_datasets(betas, alphas, X, sigma[3])
    sigma4array1, sigma4array2 = synthetic_datasets(betas, alphas, X, sigma[4])
    sigma5array1, sigma5array2 = synthetic_datasets(betas, alphas, X, sigma[5])
    sigma6array1, sigma6array2 = synthetic_datasets(betas, alphas, X, sigma[6])
    sigma7array1, sigma7array2 = synthetic_datasets(betas, alphas, X, sigma[7])
    sigma8array1, sigma8array2 = synthetic_datasets(betas, alphas, X, sigma[8])

    beta0array1 = compute_betas(sigma0array1, [1])
    beta0array2 = compute_betas(sigma0array2, [1])
    beta1array1 = compute_betas(sigma1array1, [1])
    beta1array2 = compute_betas(sigma1array2, [1])
    beta2array1 = compute_betas(sigma2array1, [1])
    beta2array2 = compute_betas(sigma2array2, [1])
    beta3array1 = compute_betas(sigma3array1, [1])
    beta3array2 = compute_betas(sigma3array2, [1])
    beta4array1 = compute_betas(sigma4array1, [1])
    beta4array2 = compute_betas(sigma4array2, [1])
    beta5array1 = compute_betas(sigma5array1, [1])
    beta5array2 = compute_betas(sigma5array2, [1])
    beta6array1 = compute_betas(sigma6array1, [1])
    beta6array2 = compute_betas(sigma6array2, [1])
    beta7array1 = compute_betas(sigma7array1, [1])
    beta7array2 = compute_betas(sigma7array2, [1])
    beta8array1 = compute_betas(sigma8array1, [1])
    beta8array2 = compute_betas(sigma8array2, [1])

    s = len(sigma)
    c = 0

    plt.plot((sigma[0], sigma[1]), (beta0array1[0], beta1array1[0]), color='red', marker='o', linestyle='-')
    plt.plot((sigma[1], sigma[2]), (beta1array1[0], beta2array1[0]), color='red', marker='o', linestyle='-')
    plt.plot((sigma[2], sigma[3]), (beta2array1[0], beta3array1[0]), color='red', marker='o', linestyle='-')
    plt.plot((sigma[3], sigma[4]), (beta3array1[0], beta4array1[0]), color='red', marker='o', linestyle='-')
    plt.plot((sigma[4], sigma[5]), (beta4array1[0], beta5array1[0]), color='red', marker='o', linestyle='-')
    plt.plot((sigma[5], sigma[6]), (beta5array1[0], beta6array1[0]), color='red', marker='o', linestyle='-')
    plt.plot((sigma[6], sigma[7]), (beta6array1[0], beta7array1[0]), color='red', marker='o', linestyle='-')
    plt.plot((sigma[7], sigma[8]), (beta7array1[0], beta8array1[0]), color='red', marker='o', linestyle='-')
    plt.plot((sigma[0], sigma[1]), (beta0array2[0], beta1array2[0]), color='blue', marker='o', linestyle='-')
    plt.plot((sigma[1], sigma[2]), (beta1array2[0], beta2array2[0]), color='blue', marker='o', linestyle='-')
    plt.plot((sigma[2], sigma[3]), (beta2array2[0], beta3array2[0]), color='blue', marker='o', linestyle='-')
    plt.plot((sigma[3], sigma[4]), (beta3array2[0], beta4array2[0]), color='blue', marker='o', linestyle='-')
    plt.plot((sigma[4], sigma[5]), (beta4array2[0], beta5array2[0]), color='blue', marker='o', linestyle='-')
    plt.plot((sigma[5], sigma[6]), (beta5array2[0], beta6array2[0]), color='blue', marker='o', linestyle='-')
    plt.plot((sigma[6], sigma[7]), (beta6array2[0], beta7array2[0]), color='blue', marker='o', linestyle='-')
    plt.plot((sigma[7], sigma[8]), (beta7array2[0], beta8array2[0]), color='blue', marker='o', linestyle='-')
    plt.ylabel("MSE")
    plt.xlabel("Sigma")
    plt.xscale("log")
    plt.yscale("log")
    red_patch = mpatches.Patch(color='red', label='Linear')
    blue_patch = mpatches.Patch(color='blue', label='Quadratic')
    plt.legend(handles=[red_patch, blue_patch], loc="best")
    plt.savefig("mse.pdf")

    return 0


if __name__ == '__main__':
    # DO NOT CHANGE THIS SECTION ###
    plot_mse()
