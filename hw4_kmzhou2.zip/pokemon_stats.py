import csv
import numpy as np
from numpy.linalg import norm
import random
import matplotlib.pyplot as plt
import math


def load_data(filepath):
    # takes in a string with a path to a CSV file formatted as in the link above, and returns the first 20 data points
    # (without the Generation and Legendary columns but retaining all other columns) in a single structure.

    with open(filepath, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        n = 0
        lst = []
        for row in reader:
            if n < 20:
                row["#"] = int(row["#"])
                row["Total"] = int(row["Total"])
                row["HP"] = int(row["HP"])
                row["Attack"] = int(row["Attack"])
                row["Defense"] = int(row["Defense"])
                row["Sp. Atk"] = int(row["Sp. Atk"])
                row["Sp. Def"] = int(row["Sp. Def"])
                row["Speed"] = int(row["Speed"])
                del row["Generation"]
                del row["Legendary"]
                lst.append(row)
            n = n + 1;

        return lst


def calculate_x_y(stats):
    # takes in one row from the data loaded from the previous function, calculates the corresponding x, y values
    # for that Pokemon as specified above, and returns them in a single structure.
    dic = dict()
    dic = stats
    x = dic["Attack"]
    x = x + dic["Sp. Atk"]
    x = x + dic["Speed"]
    y = dic["Defense"]
    y = y + dic["Sp. Def"]
    y = y + dic["HP"]
    result = tuple()
    result = (x, y)

    return result


def hac(dataset):
    # performs single linkage hierarchical agglomerative clustering on the Pokemon with the (x,y)
    # feature representation, and returns a data structure representing the clustering.

    a = 0
    while a < len(dataset):
        lis = list(dataset[a])
        if math.isnan(lis[0]) or math.isnan(lis[1]) or math.isinf(lis[0]) or math.isinf(lis[1]):
            dataset.pop(a)
        a += 1
    size = len(dataset)
    result = np.zeros((size-1, 4))
    x = 0
    arr = list()
    while x < size:
        arr.append(x)
        x += 1

    y = 0
    lst = list()
    while y < size:
        lst.append(1)
        y += 1

    data1 = np.array(dataset[0])
    data2 = np.array(dataset[1])
    small = norm(data1 - data2)

    num1 = int(arr[0])
    num2 = int(arr[1])
    num = size
    minimum = 0
    number = 1
    n = 0
    k = num1
    l = num2
    while number < size:
        i = 0
        while i < size:
            j = 0
            while j < size:
                if i != j:
                    c1 = int(arr[i])
                    c2 = int(arr[j])
                    if c1 != c2:
                        data1 = np.array(dataset[i])
                        data2 = np.array(dataset[j])
                        distance = abs(norm(data1 - data2))
                        if distance < small:
                            small = distance
                            num1 = arr[i]
                            k = i
                            num2 = arr[j]
                            l = j
                j += 1
            i += 1

        minimum = small
        length = lst[num1] + lst[num2]
        arr[k] = num
        arr[l] = num
        p = 0

        while p < len(arr):
            if p != k and p != l:
                if arr[p] == num1 or arr[p] == num2:
                    arr[p] = num
            p += 1

        lst.append(length)
        number = length
        if num1 < num2:
            result[n][0] = num1
            result[n][1] = num2
            result[n][2] = small
            result[n][3] = length
        if num1 > num2:
            result[n][0] = num2
            result[n][1] = num1
            result[n][2] = small
            result[n][3] = length
        n += 1
        num += 1
        small = 1000000000000000000

    return result


def random_x_y(m):
    # takes in the number of samples we want to randomly generate, and returns these samples
    # in a single structure.
    res = list()
    i = 0
    while i < m:
        x = int(random.random() * 360)
        y = int(random.random() * 360)
        t = tuple
        t = (x, y)
        res.append(t)
        i += 1
    return res


def imshow_hac(dataset):
    # performs single linkage hierarchical agglomerative clustering on the Pokemon with
    # the (x,y) feature representation, and imshow the clustering process.
    a = 0
    while a < len(dataset):
        lis = list(dataset[a])
        if math.isnan(lis[0]) or math.isnan(lis[1]) or math.isinf(lis[0]) or math.isinf(lis[1]):
            dataset.pop(a)
        a += 1
    b = 0
    while b < len(dataset):
        res = list(dataset[b])
        plt.scatter(res[0], res[1])
        b += 1

    size = len(dataset)
    result = np.zeros((size-1, 4))
    x = 0
    arr = list()
    while x < size:
        arr.append(x)
        x += 1

    y = 0
    lst = list()
    while y < size:
        lst.append(1)
        y += 1

    data1 = np.array(dataset[0])
    data2 = np.array(dataset[1])
    small = norm(data1 - data2)

    num1 = int(arr[0])
    num2 = int(arr[1])
    num = size
    minimum = 0
    number = 1
    n = 0
    k = num1
    l = num2
    while number < size:
        i = 0
        while i < size:
            j = 0
            while j < size:
                if i != j:
                    c1 = int(arr[i])
                    c2 = int(arr[j])
                    if c1 != c2:
                        data1 = np.array(dataset[i])
                        data2 = np.array(dataset[j])
                        distance = abs(norm(data1 - data2))
                        if distance < small:
                            small = distance
                            num1 = arr[i]
                            k = i
                            num2 = arr[j]
                            l = j
                j += 1
            i += 1

        minimum = small
        length = lst[num1] + lst[num2]
        arr[k] = num
        arr[l] = num
        p = 0
        a = list(dataset[k])
        b = list(dataset[l])
        d1 = (int(a[0]), int(b[0]))
        d2 = (int(a[1]), int(b[1]))
        plt.plot(d1, d2)
        plt.pause(.1)
        while p < len(arr):
            if p != k and p != l:
                if arr[p] == num1 or arr[p] == num2:
                    arr[p] = num
            p += 1

        lst.append(length)
        number = length
        if num1 < num2:
            result[n][0] = num1
            result[n][1] = num2
            result[n][2] = small
            result[n][3] = length
        if num1 > num2:
            result[n][0] = num2
            result[n][1] = num1
            result[n][2] = small
            result[n][3] = length
        n += 1
        num += 1
        small = 1000000000000000000
    plt.show()
    plt.pause(5)
    return 0
