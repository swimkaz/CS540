import scipy.linalg
import numpy as np
import matplotlib.pyplot as plt


def load_and_center_dataset(filename):
    x = np.load(filename)
    return x - np.mean(x, axis = 0)


def get_covariance(dataset):
    i = 0
    n = 2414
    mat = np.matrix(dataset)
    data = np.matrix(np.dot(np.transpose(mat[i]), mat[i]))
    i += 1
    while i < 2414:
        data += np.dot(np.transpose(mat[i]), mat[i])
        i += 1

    data = data/(n - 1)
    return data


def get_eig(S, m):
    n = len(S)
    a, b = scipy.linalg.eigh(a=S, subset_by_index=[n - m, n - 1])
    c = len(a)
    val = np.zeros((c, c))
    print(a)
    print(b)
    e = 0
    arr = np.array(b)
    while e < len(a):
        res1: int = a[e]
        res3 = res1
        f = e
        r: int = e
        while f < len(a):
            res2: int = a[f]
            if res2 > res3:
                res3 = res2
                r = f
            f += 1

        val[e][e] = res3
        a[r] = res1
        temp = np.copy(arr[:, e])
        arr[:, e] = np.copy(arr[:, r])
        arr[:, r] = np.copy(temp)
        e += 1

    return val, arr


def get_eig_perc(S, perc):
    n = len(S)
    m, p = scipy.linalg.eigh(a=S)
    k, j = scipy.linalg.eigh(a=S, subset_by_index=[n-1, n-1])
    maximum = k[0]
    arr = np.array(m)
    sum = 0
    i = 0
    while i < len(arr):
        z: int = arr[i]
        sum += z
        i += 1

    percent = perc * sum

    a, b = scipy.linalg.eigh(a=S, subset_by_value=[percent, maximum+1])
    c = len(a)
    val = np.zeros((c, c))
    e = 0
    arr = np.array(b)
    while e < len(a):
        res1: int = a[e]
        res3 = res1
        f = e
        r: int = e
        while f < len(a):
            res2: int = a[f]
            if res2 > res3:
                res3 = res2
                r = f
            f += 1

        val[e][e] = res3
        a[r] = res1
        temp = np.copy(arr[:, e])
        arr[:, e] = np.copy(arr[:, r])
        arr[:, r] = np.copy(temp)
        e += 1

    return val, arr


def project_image(img, U):
    array = np.array(U)
    mat = np.array(img)
    m = len(array[0])
    alphas = np.dot(np.transpose(array[:, 0]), mat)
    results = np.dot(alphas, array[:, 0])
    j = 1
    while j < m:
        alphas = np.dot(np.transpose(array[:, j]), mat)
        res = np.dot(alphas, array[:, j])
        results += res
        j += 1
    return results


def display_image(orig, proj):
    original = np.array(orig)
    project = np.array(proj)
    project = project.reshape(32, 32, order='F')
    original = original.reshape(32, 32, order='F')

    fig, (ax1, ax2) = plt.subplots(1, 2)
    ax1.set_title('Original')
    ax2.set_title('Projection')
    pos1 = ax1.imshow(original, aspect='equal')
    pos2 = ax2.imshow(project, aspect='equal')
    fig.colorbar(pos1, ax=ax1, fraction=0.046)
    fig.colorbar(pos2, ax=ax2, fraction=0.046)
    return plt.show()

